package com.example.myportfolio

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ModifierLocalBeyondBoundsLayout
import androidx.compose.ui.unit.dp

@Composable
fun ExperienceScreen(){

  Surface(modifier = Modifier
    .padding(5.dp,30.dp,5.dp)
    .fillMaxWidth()
    .height(400.dp)) {
    Card(onClick = { /*TODO*/ }) {
      Column {
        Text(text = "Will be updated soon")
        Spacer(modifier = Modifier.size(5.dp))
        Text(text = "Thanks for considering")
        Spacer(modifier = Modifier.size(5.dp))
      }
    }
  }
}
