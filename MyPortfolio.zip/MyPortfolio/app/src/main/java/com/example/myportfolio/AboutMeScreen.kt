package com.example.myportfolio

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AboutMeScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Image(painter = painterResource(id = R.drawable.profile), contentDescription =" " )
        AboutMeItem("Name", "Angad Yadav")
        AboutMeItem("College", "Greater Noida Institute of Technology")
        AboutMeItem("School", "Jawahar Navodaya Vidyalaya Gorxxxx xxxxganj")
        AboutMeItem("Branch", "Computer Science & Engineer")
        AboutMeItem("Address", "Gajbhxxx, xxxx Bazar, Goraxxxx, 273xxxxx")
        AboutMeItem("Qualification", "Bachelor of Engineering")
        AboutMeItem("Phone Number", "+91638xxxxxxx")
        AboutMeItem("Email", "angaxxxxxx@gmail.com")
    }
}

@Composable
fun AboutMeItem(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 16.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge,
            fontSize = 18.sp
        )
    }
}
