package com.example.myportfolio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myportfolio.ui.theme.MyPortfolioTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val navController = rememberNavController()

            MyPortfolioTheme {
                Navigation(navController = navController)
            }
        }
    }
}
@Composable
fun Navigation(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "profile") {
        addDestinations(navController = navController)
    }
}

private fun NavGraphBuilder.addDestinations(navController: NavController) {
    composable("profile") { MyProfile(navController = navController) }
    composable("achievements") { AchievementScreen() }
    composable("experience") { ExperienceScreen() }
    composable("contact") { ContactScreen() }
    composable("about_me") { AboutMeScreen() }
}
data class Project(val name: String, val desc: String)

@Composable
fun MyProfile(navController: NavController) {
    // Define onClick handlers for navigation
    val navigateToAchievements = { navController.navigate("achievements") }
    val navigateToExperience = { navController.navigate("experience") }
    val navigateToContact = { navController.navigate("contact") }
    val navigateToAboutMe = { navController.navigate("about_me") }
    val isProjectOpen = remember { mutableStateOf(false) }

    Surface(
        shadowElevation = 10.dp,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .padding(2.dp, 28.dp, 0.dp, 2.dp)
            .fillMaxSize()
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Image(
                painter = painterResource(id = R.drawable.profile),
                contentDescription = "Profile Image",
                modifier = Modifier
                    .width(250.dp)
                    .height(180.dp)

            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Angad Yadav",
                fontSize = 31.sp,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Android Compose Developer",
                fontSize = 20.sp,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(8.dp))
            SocialLinksRow(
                githubUrl = "/imangadydv",
                linkedinUrl = "/imangadydv"
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Show Projects and About Me Buttons in a Row
            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Show/Hide Projects Button
                Button(
                    onClick = {
                        isProjectOpen.value = !isProjectOpen.value
                    }
                ) {
                    Text(text = if (isProjectOpen.value) {
                        "Hide Projects"
                    } else "Show Projects")
                }

            }

            // Projects List
            if (isProjectOpen.value) {
                Spacer(modifier = Modifier.height(16.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(getProjectList()) { project ->
                        ProjectItem(project = project)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
            // Explore Sections Text
            Spacer(modifier = Modifier.height(25.dp))
            Text(
                text = "Explore Sections",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(vertical = 16.dp)
            )

            // Card Section Row
            Column(
                modifier = Modifier.fillMaxWidth(),
            ) {
                CardSection(
                    title = "ACHIEVEMENTS",
                    onClick = navigateToAchievements
                )
                CardSection(
                    title = "EXPERIENCE",
                    onClick = navigateToExperience

                )
                CardSection(
                    title = "CONTACT",
                    onClick = navigateToContact
                )
                CardSection(
                    title = "ABOUT ME",
                    onClick = navigateToAboutMe

                )
            }
        }
    }
}


@Composable
fun CardSection(title: String,onClick: () -> Unit) {
    val cardColors = listOf(
        Color(0xFF82DFEB), // Light Blue
        Color(0xFF6CA4E0), // Light Orange
        Color(0xFF9EA8E6), // Light Purple
    )

    val randomColor = cardColors.random()
    Card(
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .padding(8.dp)
            .clickable(onClick =  onClick)
            .fillMaxWidth()
            .height(70.dp),
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
                .background(color = randomColor)
            ,
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}


@Composable
fun SocialLinksRow(githubUrl: String, linkedinUrl: String) {
    val context = LocalContext.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = R.drawable.github),
            modifier = Modifier.size(30.dp),
            contentDescription = "GitHub Logo"
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = githubUrl,
            fontSize = 20.sp,
            color = Color.Blue,
            modifier = Modifier.clickable {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com$githubUrl"))
                context.run {startActivity(intent) }
            }
        )
        Spacer(modifier = Modifier.width(16.dp))
        Image(
            painter = painterResource(id = R.drawable.linkedin),
            modifier = Modifier.size(30.dp),
            contentDescription = "LinkedIn Logo"
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = linkedinUrl,
            fontSize = 20.sp,
            color = Color.Blue,
            modifier = Modifier.clickable {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com/in$linkedinUrl"))
                context.startActivity(intent)

            }
        )
    }
}
@Composable
fun ProjectItem(project: Project) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Image(
            painter = painterResource(id = android.R.drawable.ic_input_get),
            contentDescription = "Project Icon",
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(text = project.name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = project.desc, fontSize = 14.sp)
        }
    }
}

fun getProjectList(): List<Project> {
    return listOf(
        Project(name = "PORTFOLIO ", desc = "Know me transparently"),
        Project(name = "HOTEL BOOKING", desc = "Book safety"),
        Project(name = "Project 3", desc = "Description of Project 3")
    )
}

