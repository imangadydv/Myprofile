package com.example.myportfolio

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// Define data model for Achievement
data class Achievement(val title: String, val description: String)

@Composable
fun AchievementScreen() {
    // Dummy data for achievements
    val achievements = listOf(
        Achievement(
            title = "National Player in Taekwondo",
            description = "Represented at national level tournaments."
        ),
        Achievement(
            title = "International English Olympiad 16th Rank",
            description = "Achieved 16th rank in the International English Olympiad."
        ),
        Achievement(
            title = "DSA Certificate Holder in C and C++",
            description = "Certified in Data Structures and Algorithms in C and C++."
        )
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Achievements",
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(vertical = 16.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            items(achievements) { achievement ->
                AchievementCard(achievement = achievement)
            }
        }
    }
}

@Composable
fun AchievementCard(achievement: Achievement) {
    Card(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 8.dp),
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = achievement.title,
                style = MaterialTheme.typography.labelSmall
            )
            Text(
                text = achievement.description,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
